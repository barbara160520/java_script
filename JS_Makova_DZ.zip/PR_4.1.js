'use static'
class Generator {
    constructor(number) {
        this.number = number;

        if (number <= 9 && number >= 0) {
            this.units = number.toString().slice(-1);
            this.tens = "0";
            this.hundreds = "0";
        } else if (number <= 99 && number >= 10) {
            this.units = number.toString().slice(-1);
            this.tens = number.toString().slice(-2, 1);
            this.hundreds = "0";
        } else {
            this.units = number.toString().slice(-1);
            this.tens = number.toString().slice(1, 2);
            this.hundreds = number.toString().slice(0, 1);
        }
    }
    output() {
        alert(this.units + " - единицы\n" + this.tens + " - десятки\n" + this.hundreds + " - сотни");
    }
}


let number = parseInt(prompt("Введите целое число от 0 до 999")); //окуругляет

//не выходит из программы после break
while (number != false) {
    if (number > 999 || number < 0) {
        alert("Вы вышли за рамки диапазона");
        break;
    } else if (isNaN(number) == true || number == undefined) {
        alert("Вы ввели не число");
        break;
    } else if (Number.isInteger(number) == false) {
        alert("Вы ввели не целое число или вообще не ввели число");
        break;
    }
    break;
}

let convert_num = new Generator(number);
convert_num.output();
