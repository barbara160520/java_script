for(let i = 0; numbers(i);i++){
    
}
function numbers(i){
    do{
        console.log(i); 
        i++;
    }while(i<=9)
}