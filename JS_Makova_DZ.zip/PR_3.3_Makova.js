const product = [
    {
        id: 3,
        price: 200,
    },
    {
        id: 4,
        price: 900,
    },
    {
        id: 1,
        price: 1000,
    },
];
product.forEach(sale=>{
    sale.price = sale.price-(sale.price /100)*15;
});
console.log(product);