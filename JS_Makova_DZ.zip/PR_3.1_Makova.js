let arr_num = [0,1,2,3,4,5,6,7,8,9,10];
for(let i =0;arr_num.length > i; i++){
    if (arr_num[i] == 0){
    console.log(arr_num[i] + " - это ноль");
    } else if(arr_num[i]%2 == 0) {
        console.log(arr_num[i] + " - четное число");
    }
    else (console.log(arr_num[i] + " - нечетное число"))
}