const products = [
    {
        id: 3,
        price: 127,
        photos: [
            "1.jpg",
            "2.jpg",
        ]
    },
    {
        id: 5,
        price: 499,
        photos: []
    },
    {
        id: 10,
        price: 26,
        photos: [
            "3.jpg"
        ]
    },
    {
        id: 8,
        price: 78,
        
    },
];

let arr1 = products.filter(photo => {
    if (photo.photos.length > 0 && "photos" in photo.photos) {
        return photo;
    }
}); //Cannot read property 'length' of undefined

console.log(arr1);
console.log(products.sort(function(a,b){
    if(a.price > b.price){
        return 1;
    }
    if(a.price < b.price){
        return -1;
    }
    return 0;
}));