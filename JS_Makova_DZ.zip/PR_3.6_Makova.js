/*let mount ="x";
do{
    console.log(mount);
    mount += "x";
} while (mount.length <= 20);*/

for (let mount ="x";mount.length <= 20;mount += "x"){
    console.log(mount);
}