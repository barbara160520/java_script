'use strict'
//ES6
class Post_es6{
    constructor(text,author,date){
        this.text = text;
        this.author = author;
        this.date = date;
    }
    edit(text){
        this.text = text;
    }
}
class AttachedPost_es6 extends Post_es6{
    constructor(text,author,date,highlighted){
        super(text,author,date);
        this.highlighted = false;
    }
    makeTextHighlighted(){
        this.highlighted = true;
    }
}
let post1 = new Post_es6("why?","Felex","25.03.2020");
post1.edit("no");
let post2 = new AttachedPost_es6("yes","Molly","26.04.2020")
post2.makeTextHighlighted();
post2.edit("what?");
console.log(post1);
console.log(post2);
//ES5
function Post_es5(text, author, date) {
    this.text = text;
    this.author = author;
    this.date = date;
}
Post_es5.prototype.edit = function (text) {
    this.text = text;
}

function AttachedPost_es5(text, author, date, highlighted) {
    Post_es5.call(this, text, author, date)
    this.highlighted = false;
}
AttachedPost_es5.prototype = Object.create(Post_es5.prototype);
AttachedPost_es5.prototype.constructor = AttachedPost_es5;
AttachedPost_es5.prototype.makeTextHighlighted = function(){
   this.highlighted = true; 
}
let post3 = new Post_es5("yes?","Martin","27.03.2020");
post3.edit("maybe");
let post4 = new AttachedPost_es5("no comments","Frank","15.07.2020")
post4.makeTextHighlighted();
post4.edit("before?");
console.log(post3);
console.log(post4);