'use strict'
//ES6
class Product_es6{
    constructor(name,price){
        this.name = name;
        this.price = price;
    }
    make25PercentDiscount(){
        this.price = this.price * 0.25;
    }
}
let obj1 = new Product_es6("Felex", 500);
obj1.make25PercentDiscount();
console.log(obj1);
//ES5
function Product_es5(name,price){
    this.name = name;
    this.price = price;
}
Product_es5.prototype.make25PercentDiscount = function(){
    this.price = this.price*0.25;
}
let obj2 = new Product_es5("Molly", 1500);
obj2.make25PercentDiscount();
console.log(obj2);

